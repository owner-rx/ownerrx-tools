#!/usr/bin/env python3
"""
Strategy model evaluator for search-visibility plugin.
Takes audit results and evaluates which distribution models fit the business.
"""

import json
import re
import sys


SAAS_SIGNALS = re.compile(
    r"\b(?:saas|software|platform|app|tool|dashboard|api|crm|erp|"
    r"subscription|sign\s*up|free\s*trial|pricing|plans)\b",
    re.IGNORECASE,
)
CONTENT_SIGNALS = re.compile(
    r"\b(?:blog|newsletter|media|publish|article|insight|analysis|report|"
    r"editorial|magazine|journal)\b",
    re.IGNORECASE,
)
SERVICE_SIGNALS = re.compile(
    r"\b(?:consult|coach|agency|service|advisory|firm|practice|"
    r"engagement|retainer|hourly)\b",
    re.IGNORECASE,
)


def classify_business_type(page_audit: dict, site_audit: dict) -> dict:
    meta = page_audit.get("meta", {})
    combined_text = f"{meta.get('title', '')} {meta.get('description', '')}"

    saas_score = len(SAAS_SIGNALS.findall(combined_text))
    content_score = len(CONTENT_SIGNALS.findall(combined_text))
    service_score = len(SERVICE_SIGNALS.findall(combined_text))

    found_paths = [p.get("path", "") for p in site_audit.get("found", [])]
    if "/pricing" in found_paths or "/docs" in found_paths:
        saas_score += 2
    if "/blog" in found_paths:
        content_score += 1

    clusters = page_audit.get("internal_links", {}).get("cluster_groups", {})
    if "docs" in clusters or "api" in clusters or "templates" in clusters:
        saas_score += 2

    scores = {
        "saas_product": saas_score,
        "content_publisher": content_score,
        "service_business": service_score,
    }

    best_type = max(scores, key=scores.get)
    best_score = scores[best_type]

    if best_score == 0:
        best_type = "service_business"

    return {
        "type": best_type,
        "confidence": "high" if best_score >= 3 else "medium" if best_score >= 1 else "low",
        "signals": scores,
    }


def evaluate_models(
    page_audit: dict,
    site_audit: dict,
    competitor_data: dict,
    competitor_site_audits: dict,
) -> dict:
    btype = classify_business_type(page_audit, site_audit)
    business_type = btype["type"]

    models = []

    # --- Reddit Model ---
    reddit_applicable = business_type in ("saas_product", "content_publisher")
    reddit_priority = "medium"
    reddit_rationale = ""
    if reddit_applicable:
        reddit_rationale = (
            "Your category has knowledge-sharing potential on Reddit. "
            "Post structured breakdowns targeting decision-level queries "
            "that LLMs pull from community-validated threads."
        )
        if business_type == "saas_product":
            reddit_priority = "high"
            reddit_rationale = (
                "SaaS products benefit most from Reddit citation seeding. "
                "Create comparison threads and how-to breakdowns in relevant subreddits."
            )
    else:
        reddit_rationale = (
            "Service businesses have limited Reddit citation potential. "
            "Focus on documentation and thought leadership content instead."
        )

    reddit_gap = _competitor_reddit_gap(competitor_data)

    models.append({
        "model": "reddit",
        "applicable": reddit_applicable,
        "priority": reddit_priority,
        "rationale": reddit_rationale,
        "competitor_gap": reddit_gap,
    })

    # --- Lovable Model ---
    lovable_applicable = business_type in ("saas_product", "content_publisher")
    lovable_priority = "low"
    lovable_rationale = ""
    if lovable_applicable:
        lovable_rationale = (
            "Publish metric-driven posts about your progress with searchable titles. "
            "Make yourself the primary source for your own growth narrative."
        )
        if business_type == "saas_product":
            lovable_priority = "medium"
    else:
        lovable_rationale = (
            "Service businesses rarely have publishable product metrics. "
            "Consider publishing case study results with specific numbers instead."
        )

    models.append({
        "model": "lovable",
        "applicable": lovable_applicable,
        "priority": lovable_priority,
        "rationale": lovable_rationale,
        "competitor_gap": "",
    })

    # --- Replit Model ---
    replit_applicable = business_type == "saas_product"
    replit_priority = "low"
    replit_rationale = ""
    if replit_applicable:
        clusters = page_audit.get("internal_links", {}).get("cluster_groups", {})
        has_templates = "templates" in clusters or "examples" in clusters
        replit_rationale = (
            "Your product can generate indexable pages from usage. "
            "Templates, examples, public outputs — each gets its own URL."
        )
        if has_templates:
            replit_priority = "high"
            replit_rationale = (
                "You already have template/example content. "
                "Ensure each has a unique, indexable URL with structured metadata."
            )
        else:
            replit_priority = "medium"
    else:
        replit_rationale = (
            "This model requires a product that generates user-visible, indexable outputs. "
            "Not applicable for service or content-only businesses."
        )

    models.append({
        "model": "replit",
        "applicable": replit_applicable,
        "priority": replit_priority,
        "rationale": replit_rationale,
        "competitor_gap": "",
    })

    # --- Documentation Architecture ---
    doc_priority = "high" if site_audit.get("coverage_score", 0) < 50 else "medium"
    missing_high = [p for p in site_audit.get("missing", []) if p.get("priority") == "high"]
    doc_rationale = (
        f"Site coverage is {site_audit.get('coverage_score', 0)}%. "
        f"{len(missing_high)} high-priority canonical pages missing. "
        "Documentation is the highest-impact structural play for AI citation."
    )
    doc_gap = _competitor_doc_gap(site_audit, competitor_site_audits)

    models.append({
        "model": "documentation",
        "applicable": True,
        "priority": doc_priority,
        "rationale": doc_rationale,
        "competitor_gap": doc_gap,
    })

    priority_order = {"high": 0, "medium": 1, "low": 2}
    models.sort(key=lambda m: (
        0 if m["applicable"] else 1,
        priority_order.get(m["priority"], 3),
    ))

    return {
        "business_type": btype,
        "models": models,
    }


def _competitor_reddit_gap(competitor_data: dict) -> str:
    competitors = competitor_data.get("competitors", [])
    if competitors:
        names = ", ".join(c["name"] for c in competitors[:3])
        return f"Check Reddit for threads mentioning {names} in your category."
    return "No competitors identified for Reddit gap analysis."


def _competitor_doc_gap(site_audit: dict, competitor_site_audits: dict) -> str:
    if not competitor_site_audits:
        return "No competitor site audits available for comparison."

    own_score = site_audit.get("coverage_score", 0)
    gaps = []
    for comp_url, comp_audit in competitor_site_audits.items():
        comp_score = comp_audit.get("coverage_score", 0)
        if comp_score > own_score:
            comp_found = [p.get("path", "") for p in comp_audit.get("found", [])]
            own_missing = [p.get("path", "") for p in site_audit.get("missing", [])]
            overlap = [p for p in comp_found if p in own_missing]
            if overlap:
                gaps.append(f"{comp_url} has {', '.join(overlap)} that you're missing")

    if gaps:
        return "; ".join(gaps) + "."
    return "Competitors have similar documentation coverage."


def main():
    data = json.loads(sys.stdin.read())
    result = evaluate_models(
        data.get("page_audit", {}),
        data.get("site_audit", {}),
        data.get("competitor_data", {}),
        data.get("competitor_site_audits", {}),
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
