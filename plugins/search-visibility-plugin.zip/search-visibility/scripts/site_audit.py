#!/usr/bin/env python3
"""
Site-level canonical page auditor.
Checks whether a domain has key canonical pages that improve AI discoverability.
"""

import json
import sys
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup


CANONICAL_PAGES = [
    {"path": "/how-it-works", "purpose": "Process explanation", "priority": "high"},
    {"path": "/use-cases", "purpose": "Task-based examples", "priority": "high"},
    {"path": "/pricing", "purpose": "Decision-level query magnet", "priority": "high"},
    {"path": "/faq", "purpose": "FAQ schema opportunity", "priority": "high"},
    {"path": "/about", "purpose": "E-E-A-T / author credentials", "priority": "high"},
    {"path": "/glossary", "purpose": "Term definitions — high AI citation value", "priority": "medium"},
    {"path": "/changelog", "purpose": "Freshness signal + trust", "priority": "medium"},
    {"path": "/blog", "purpose": "Content hub", "priority": "medium"},
    {"path": "/docs", "purpose": "Structured knowledge — claude.md principle", "priority": "medium"},
    {"path": "/documentation", "purpose": "Structured knowledge (alternate path)", "priority": "medium"},
]


def check_page_exists(url: str) -> dict:
    """Check if a URL returns a live page with content."""
    try:
        resp = requests.get(url, timeout=10, headers={"User-Agent": "SEO-Audit-Bot/1.0"})
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.text, "html.parser")
            title_tag = soup.find("title")
            title = title_tag.text.strip() if title_tag else ""
            body = soup.find("body") or soup
            word_count = len(body.get_text(strip=True).split())
            schema_types = []
            for script in soup.find_all("script", type="application/ld+json"):
                try:
                    data = json.loads(script.string)
                    items = data if isinstance(data, list) else [data]
                    for item in items:
                        if isinstance(item, dict) and "@type" in item:
                            schema_types.append(item["@type"])
                except (json.JSONDecodeError, TypeError):
                    continue
            return {
                "exists": True,
                "status_code": 200,
                "title": title,
                "word_count": word_count,
                "schema_types": schema_types,
            }
        return {"exists": False, "status_code": resp.status_code}
    except Exception as e:
        return {"exists": False, "error": str(e)}


def check_canonical_pages(base_url: str) -> dict:
    """Check all canonical pages for a domain."""
    parsed = urlparse(base_url)
    base = f"{parsed.scheme}://{parsed.netloc}"

    pages = []
    found = []
    missing = []

    for canonical in CANONICAL_PAGES:
        url = f"{base}{canonical['path']}"
        result = check_page_exists(url)
        entry = {
            "path": canonical["path"],
            "purpose": canonical["purpose"],
            "priority": canonical["priority"],
            **result,
        }
        pages.append(entry)
        if result.get("exists"):
            found.append(entry)
        else:
            missing.append(entry)

    total = len(CANONICAL_PAGES)
    coverage = (len(found) / total * 100) if total else 0

    return {
        "base_url": base,
        "pages": pages,
        "found": found,
        "missing": missing,
        "coverage_score": round(coverage, 1),
    }


def main():
    """CLI entry point."""
    if len(sys.argv) != 2:
        print("Usage: python3 site_audit.py <url>", file=sys.stderr)
        sys.exit(1)
    result = check_canonical_pages(sys.argv[1])
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
