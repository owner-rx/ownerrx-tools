"""Tests for strategy_evaluator.py — model fit evaluation."""
import json
import pytest

from strategy_evaluator import evaluate_models, classify_business_type


AUDIT_SAAS_PRODUCT = {
    "url": "https://acmecrm.com",
    "meta": {
        "title": "Acme CRM - Project Management for Small Teams",
        "description": "Acme CRM helps small teams manage projects, track leads, and close deals faster.",
    },
    "content": {"word_count": 1200, "faq_detected": True, "sections": []},
    "query_intent": {"intent_type": "branded", "is_decision_query": False},
    "internal_links": {"count": 8, "orphan_risk": False, "cluster_groups": {"blog": ["/blog/a"], "docs": ["/docs/b"]}},
    "technical": {"schema_types": ["Organization"], "is_ssr": True},
}

SITE_AUDIT_SAAS = {
    "coverage_score": 40.0,
    "found": [
        {"path": "/pricing", "exists": True},
        {"path": "/about", "exists": True},
        {"path": "/blog", "exists": True},
    ],
    "missing": [
        {"path": "/how-it-works", "priority": "high"},
        {"path": "/use-cases", "priority": "high"},
        {"path": "/docs", "priority": "medium"},
        {"path": "/glossary", "priority": "medium"},
        {"path": "/changelog", "priority": "medium"},
        {"path": "/faq", "priority": "high"},
    ],
}

COMPETITOR_DATA = {
    "competitors": [
        {"name": "Rival CRM", "url": "https://rivalcrm.com"},
    ],
}

COMPETITOR_SITE_AUDITS = {
    "https://rivalcrm.com": {
        "coverage_score": 70.0,
        "found": [
            {"path": "/docs", "exists": True},
            {"path": "/changelog", "exists": True},
            {"path": "/use-cases", "exists": True},
        ],
        "missing": [],
    }
}


class TestClassifyBusinessType:
    def test_saas_product(self):
        btype = classify_business_type(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS)
        assert btype["type"] == "saas_product"

    def test_content_site(self):
        audit = {
            "url": "https://myblog.com",
            "meta": {
                "title": "My Blog - Insights on Technology",
                "description": "A blog about technology trends and insights for business owners.",
            },
            "content": {"word_count": 3000, "faq_detected": False, "sections": []},
            "query_intent": {"intent_type": "definition", "is_decision_query": False},
            "internal_links": {"count": 15, "orphan_risk": False, "cluster_groups": {"blog": list(range(12))}},
            "technical": {"schema_types": ["Article"], "is_ssr": True},
        }
        site = {"coverage_score": 20.0, "found": [{"path": "/blog"}], "missing": []}
        btype = classify_business_type(audit, site)
        assert btype["type"] == "content_publisher"

    def test_service_business(self):
        audit = {
            "url": "https://myconsulting.com",
            "meta": {
                "title": "Smith Consulting - Business Strategy",
                "description": "Executive coaching and business strategy consulting for growth-stage companies.",
            },
            "content": {"word_count": 800, "faq_detected": False, "sections": []},
            "query_intent": {"intent_type": "branded", "is_decision_query": False},
            "internal_links": {"count": 3, "orphan_risk": False, "cluster_groups": {}},
            "technical": {"schema_types": [], "is_ssr": True},
        }
        site = {"coverage_score": 20.0, "found": [{"path": "/about"}], "missing": []}
        btype = classify_business_type(audit, site)
        assert btype["type"] == "service_business"


class TestEvaluateModels:
    def test_returns_all_four_models(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        model_names = [m["model"] for m in result["models"]]
        assert "reddit" in model_names
        assert "lovable" in model_names
        assert "replit" in model_names
        assert "documentation" in model_names

    def test_each_model_has_required_fields(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        for model in result["models"]:
            assert "model" in model
            assert "applicable" in model
            assert isinstance(model["applicable"], bool)
            assert "priority" in model
            assert model["priority"] in ("high", "medium", "low")
            assert "rationale" in model
            assert isinstance(model["rationale"], str)

    def test_documentation_always_applicable(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        doc_model = [m for m in result["models"] if m["model"] == "documentation"][0]
        assert doc_model["applicable"] is True

    def test_replit_applicable_for_saas(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        replit_model = [m for m in result["models"] if m["model"] == "replit"][0]
        assert replit_model["applicable"] is True

    def test_replit_not_applicable_for_service(self):
        service_audit = {
            "url": "https://consulting.com",
            "meta": {"title": "Consulting", "description": "We provide consulting services."},
            "content": {"word_count": 500, "faq_detected": False, "sections": []},
            "query_intent": {"intent_type": "branded", "is_decision_query": False},
            "internal_links": {"count": 2, "orphan_risk": True, "cluster_groups": {}},
            "technical": {"schema_types": [], "is_ssr": True},
        }
        service_site = {"coverage_score": 10.0, "found": [], "missing": []}
        result = evaluate_models(service_audit, service_site, COMPETITOR_DATA, {})
        replit_model = [m for m in result["models"] if m["model"] == "replit"][0]
        assert replit_model["applicable"] is False

    def test_competitor_gap_populated(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        doc_model = [m for m in result["models"] if m["model"] == "documentation"][0]
        assert "competitor_gap" in doc_model
        assert isinstance(doc_model["competitor_gap"], str)

    def test_models_sorted_by_priority(self):
        result = evaluate_models(AUDIT_SAAS_PRODUCT, SITE_AUDIT_SAAS, COMPETITOR_DATA, COMPETITOR_SITE_AUDITS)
        applicable = [m for m in result["models"] if m["applicable"]]
        priorities = [m["priority"] for m in applicable]
        priority_order = {"high": 0, "medium": 1, "low": 2}
        priority_nums = [priority_order[p] for p in priorities]
        assert priority_nums == sorted(priority_nums)
