"""Tests for site_audit.py — canonical page existence checker."""
import json
from unittest.mock import patch, MagicMock
import pytest

from site_audit import check_canonical_pages, CANONICAL_PAGES, check_page_exists


def _mock_response(status_code=200, text="<html><head><title>Page</title></head><body><h1>Page</h1><p>Content here about topics.</p></body></html>"):
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text
    resp.url = "https://example.com/page"
    return resp


class TestCheckPageExists:
    @patch("site_audit.requests.get")
    def test_page_found(self, mock_get):
        mock_get.return_value = _mock_response(200, "<html><head><title>About Us</title></head><body><h1>About</h1><p>We are a company.</p></body></html>")
        result = check_page_exists("https://example.com/about")
        assert result["exists"] is True
        assert result["title"] == "About Us"
        assert result["status_code"] == 200

    @patch("site_audit.requests.get")
    def test_page_not_found(self, mock_get):
        mock_get.return_value = _mock_response(404)
        result = check_page_exists("https://example.com/changelog")
        assert result["exists"] is False
        assert result["status_code"] == 404

    @patch("site_audit.requests.get")
    def test_page_error(self, mock_get):
        mock_get.side_effect = Exception("timeout")
        result = check_page_exists("https://example.com/about")
        assert result["exists"] is False
        assert "error" in result


class TestCheckCanonicalPages:
    @patch("site_audit.requests.get")
    def test_returns_all_canonical_paths(self, mock_get):
        mock_get.return_value = _mock_response(200)
        result = check_canonical_pages("https://example.com")
        assert "pages" in result
        assert "coverage_score" in result
        assert len(result["pages"]) == len(CANONICAL_PAGES)

    @patch("site_audit.requests.get")
    def test_coverage_score_all_found(self, mock_get):
        mock_get.return_value = _mock_response(200)
        result = check_canonical_pages("https://example.com")
        assert result["coverage_score"] == 100.0

    @patch("site_audit.requests.get")
    def test_coverage_score_none_found(self, mock_get):
        mock_get.return_value = _mock_response(404)
        result = check_canonical_pages("https://example.com")
        assert result["coverage_score"] == 0.0

    @patch("site_audit.requests.get")
    def test_missing_pages_listed(self, mock_get):
        mock_get.return_value = _mock_response(404)
        result = check_canonical_pages("https://example.com")
        assert len(result["missing"]) == len(CANONICAL_PAGES)

    @patch("site_audit.requests.get")
    def test_found_pages_listed(self, mock_get):
        mock_get.return_value = _mock_response(200)
        result = check_canonical_pages("https://example.com")
        assert len(result["found"]) == len(CANONICAL_PAGES)
