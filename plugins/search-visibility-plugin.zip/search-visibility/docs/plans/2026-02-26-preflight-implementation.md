# Preflight & Manual Competitor Discovery Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a preflight environment check and first-time setup flow to `/visibility`, and support manual competitor discovery (no OpenAI API key required).

**Architecture:** The audit skill gets a new "Preflight" section that runs before Step 1. It checks python3/pip packages, reads or creates a config file at `~/.claude/search-visibility-config.json`, and branches competitor discovery into automatic (existing Python script) or manual (Claude-native prompts + user pastes ChatGPT responses) paths.

**Tech Stack:** Markdown skill files, JSON config, existing Python scripts unchanged.

---

### Task 1: Create `/visibility-setup` command

**Files:**
- Create: `commands/visibility-setup.md`

**Step 1: Write the command file**

Create `commands/visibility-setup.md` with this exact content:

```markdown
---
name: visibility-setup
description: Configure or reconfigure the search-visibility plugin. Checks environment and sets competitor discovery mode.
user_invocable: true
---

# /visibility-setup

Reconfigure the search-visibility plugin.

## Instructions

Run the Preflight section from the `audit` skill in this plugin, but **force re-setup** even if a config file already exists at `~/.claude/search-visibility-config.json`.

1. Run the environment check (python3, pip packages).
2. If a config file exists, read it and show the current settings:
   > "Current config: Competitor discovery mode is **[manual/automatic]**. Want to change? (yes/no)"
3. If yes (or no config exists), run the first-time setup flow from the audit skill's Preflight section.
4. Save the updated config.
5. Confirm: "Setup complete. Run `/visibility [url]` to start an audit."
```

**Step 2: Verify the file**

Run: `cat ~/.claude/plugins/repos/search-visibility/commands/visibility-setup.md`
Expected: The file contents above.

**Step 3: Commit**

```bash
cd ~/.claude/plugins/repos/search-visibility && git add commands/visibility-setup.md && git commit -m "feat: add /visibility-setup command for plugin configuration"
```

---

### Task 2: Add Preflight section to audit skill

**Files:**
- Modify: `skills/audit/SKILL.md` — insert new section between line 13 (`## Workflow`) and line 15 (`### Step 1: Collect Input`)

**Step 1: Insert the Preflight section**

After line 13 (`## Workflow`) and before line 15 (`### Step 1: Collect Input`), insert:

```markdown

### Preflight: Environment & Config

Run this before anything else, every time.

**1. Check environment**

Run these two commands:

```bash
which python3
```

```bash
python3 -c "import bs4; import requests" 2>&1
```

- If `python3` is not found: stop and tell the user to install Python 3.
- If the import check fails: tell the user which package is missing and offer to run `pip install beautifulsoup4 requests`. If they decline, stop.

**2. Check config**

Read `~/.claude/search-visibility-config.json`.

- **Config exists and valid:** Print one status line and proceed:
  > `Preflight OK — python3, bs4, requests. Competitor discovery: [manual/automatic]. (/visibility-setup to change)`

- **Config missing or invalid:** Run the first-time setup flow below.

**3. First-time setup flow**

Ask the user:

> How would you like to discover who AI recommends instead of you?
>
> **A) Automatic** — Provide an OpenAI API key. I'll query ChatGPT programmatically with customer-like prompts and parse the results automatically.
>
> **B) Manual** — I'll generate 3 prompts for you to paste into ChatGPT yourself. You paste the responses back and I'll analyze them. Free, no API key needed.

**If A (automatic):**
1. Ask for their OpenAI API key.
2. Validate it by running:
   ```bash
   python3 -c "from openai import OpenAI; c = OpenAI(api_key='KEY'); c.models.list()" 2>&1
   ```
   If validation fails, report the error and ask them to try again or switch to manual mode.
3. Also check that the `openai` pip package is installed. If not, offer to run `pip install openai`.
4. Write config:
   ```json
   {"competitor_discovery": "automatic", "openai_api_key": "sk-...", "setup_version": 1}
   ```

**If B (manual):**
1. Print these instructions:
   > When we get to competitor discovery, I'll give you 3 numbered prompts. For each one:
   > 1. Open ChatGPT and start a **new Temporary Chat** (click the dropdown next to the model name, toggle "Temporary Chat" ON). This prevents ChatGPT's memory from biasing results toward brands you've discussed before.
   > 2. Each prompt gets its **own separate Temporary Chat**. Don't run multiple prompts in the same chat — ChatGPT will repeat brands from earlier responses.
   > 3. Paste the prompt, copy the full response.
   > 4. Paste all 3 responses back here, labeled 1-3.
2. Write config:
   ```json
   {"competitor_discovery": "manual", "openai_api_key": null, "setup_version": 1}
   ```

Write the config file to `~/.claude/search-visibility-config.json`.

Proceed to Step 1.
```

**Step 2: Verify the insertion**

Read `skills/audit/SKILL.md` and confirm the Preflight section appears between `## Workflow` and `### Step 1`.

**Step 3: Commit**

```bash
cd ~/.claude/plugins/repos/search-visibility && git add skills/audit/SKILL.md && git commit -m "feat: add preflight environment check and setup flow to audit skill"
```

---

### Task 3: Rewrite Step 1 competitor discovery with two paths

**Files:**
- Modify: `skills/audit/SKILL.md` — replace the current Step 1 section

**Step 1: Replace Step 1 content**

Find the current Step 1 (starts with `### Step 1: Collect Input` and ends before `### Step 2: Detect MCP Capabilities`). Replace it with:

```markdown
### Step 1: Collect Input

Ask the user for:

1. **Target URL** (primary) — or ask them to paste their page content as fallback.
2. **Brand name** — "What is your brand/company name?" (needed for competitor discovery in both modes).
3. **Competitor URLs** — "Provide 2-3 competitor URLs, OR I can discover your top AI competitors automatically."

If the user wants auto-discovery, read the competitor discovery mode from `~/.claude/search-visibility-config.json`.

**Automatic mode** (`"competitor_discovery": "automatic"`):

1. Use WebFetch to get the user's page HTML.
2. Save to a temp file and run extraction:
   ```bash
   python3 ${CLAUDE_PLUGIN_ROOT}/scripts/analyze_page.py --file /tmp/target_page.html --url {url}
   ```
3. Read the API key from the config file. Pipe extraction JSON to discover competitors:
   ```bash
   echo '{extraction_json}' | python3 ${CLAUDE_PLUGIN_ROOT}/scripts/discover_competitors.py --brand "{brand_name}" --api-key {api_key}
   ```
4. Present discovered competitors to the user for confirmation.
5. Report whether the user's brand was mentioned by AI at all.

**Manual mode** (`"competitor_discovery": "manual"`):

1. Use WebFetch to get the user's page HTML.
2. Save to a temp file and run extraction:
   ```bash
   python3 ${CLAUDE_PLUGIN_ROOT}/scripts/analyze_page.py --file /tmp/target_page.html --url {url}
   ```
3. Read the extraction JSON. From the `meta.title`, `meta.description`, and `headings.h1[0]` fields, generate 3 customer-like prompts. These should be natural questions a potential customer would ask when looking for solutions in this space. Examples of prompt patterns:
   - "What are the best alternatives for [niche inferred from title/description]?"
   - "Can you recommend the top companies or tools for [description]?"
   - "Who are the market leaders in [category]?"
4. Present the 3 prompts numbered, with this reminder:
   > Open **3 separate Temporary Chats** in ChatGPT (one per prompt). Toggle "Temporary Chat" ON each time to prevent memory bias. Paste each prompt, copy the response, then paste all 3 responses back here labeled 1-3.
5. Wait for the user to paste their responses.
6. Parse the responses:
   - Identify brand names mentioned across all 3 responses.
   - Count how many responses each brand appears in (max 3).
   - Check whether the user's brand name was mentioned in any response.
   - Rank competitors by mention frequency. Take the top 3.
7. Present results:
   - "**Competitors discovered:** [Brand1] (mentioned in 3/3 responses), [Brand2] (2/3), [Brand3] (2/3)"
   - "**Your brand ([name]):** [Mentioned in 1/3 responses / Not mentioned in any response]"
   - "**Prompts used:** [list the 3 prompts]"
8. Ask the user to confirm the competitor list or adjust it.
```

**Step 2: Verify the replacement**

Read `skills/audit/SKILL.md` and confirm Step 1 now has both automatic and manual paths, and no longer mentions "requires an OpenAI API key" in the user-facing prompt.

**Step 3: Commit**

```bash
cd ~/.claude/plugins/repos/search-visibility && git add skills/audit/SKILL.md && git commit -m "feat: rewrite Step 1 with automatic and manual competitor discovery paths"
```

---

### Task 4: Update `/visibility` command to reference preflight

**Files:**
- Modify: `commands/visibility.md` — add preflight step to Phase 1

**Step 1: Update Phase 1 instructions**

In `commands/visibility.md`, find the Phase 1 list (lines 19-25). Replace it with:

```markdown
0. **Run Preflight** — environment check + config check (see audit skill Preflight section).
1. Collect the target URL from the argument. Ask for brand name and competitor URLs (or offer auto-discovery).
2. Detect MCP capabilities (Lighthouse, Google Search Console).
3. Extract data for target and competitors (page-level + site-level).
4. Score all 6 categories.
5. Present the report card with competitor comparison.
6. Generate fixes (schema, llms.txt, robots.txt, meta, weak sections).
```

**Step 2: Verify**

Read `commands/visibility.md` and confirm step 0 (Preflight) is present and the list is numbered 0-6.

**Step 3: Commit**

```bash
cd ~/.claude/plugins/repos/search-visibility && git add commands/visibility.md && git commit -m "feat: add preflight step to /visibility command"
```

---

### Task 5: Update audit skill Dependencies section

**Files:**
- Modify: `skills/audit/SKILL.md` — update the Dependencies section at the bottom

**Step 1: Replace Dependencies section**

Find the `## Dependencies` section at the end of the file. Replace it with:

```markdown
## Dependencies

Scripts require:

```bash
pip install beautifulsoup4 requests
```

Optional (for automatic competitor discovery mode):

```bash
pip install openai
```

The preflight check at the start of the workflow validates these automatically.

## Config

Plugin config is stored at `~/.claude/search-visibility-config.json`. Run `/visibility-setup` to reconfigure.
```

**Step 2: Verify**

Read the end of `skills/audit/SKILL.md` and confirm the updated Dependencies and new Config sections.

**Step 3: Commit**

```bash
cd ~/.claude/plugins/repos/search-visibility && git add skills/audit/SKILL.md && git commit -m "feat: update dependencies section and add config reference"
```

---

### Task 6: End-to-end verification

**Step 1: Check all files are consistent**

Read these files and verify cross-references are correct:
- `commands/visibility.md` — references audit skill Preflight
- `commands/visibility-setup.md` — references audit skill Preflight
- `skills/audit/SKILL.md` — has Preflight section, Step 1 with two paths, updated Dependencies
- Config path `~/.claude/search-visibility-config.json` is consistent across all files

**Step 2: Verify no orphaned references**

Grep for "OpenAI API key" across the plugin. It should only appear in:
- `skills/audit/SKILL.md` (automatic mode setup and automatic mode Step 1)
- `discover_competitors.py` (unchanged)
- `docs/plans/` (design docs)

It should NOT appear in:
- `commands/visibility.md` (was removed)
- User-facing prompts that imply it's required

```bash
cd ~/.claude/plugins/repos/search-visibility && grep -r "OpenAI API key" --include="*.md" --include="*.py" .
```

**Step 3: Final commit if any fixups needed**

```bash
cd ~/.claude/plugins/repos/search-visibility && git log --oneline -5
```

Verify 4 commits from this implementation.
