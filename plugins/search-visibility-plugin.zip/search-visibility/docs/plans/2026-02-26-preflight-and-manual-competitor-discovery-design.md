# Preflight Check & Manual Competitor Discovery

Date: 2026-02-26

## Problem

The search-visibility plugin requires an OpenAI API key for competitor discovery. When a new user installs the plugin and runs `/visibility` with Claude Code, this dependency is unnecessary friction. Claude can generate the prompts itself. The user can run them in ChatGPT manually. No API key needed.

Additionally, the plugin has no environment validation. If `python3` or pip packages are missing, scripts fail mid-audit with cryptic errors.

## Design

### Preflight (runs at the start of every `/visibility` invocation)

**Environment check (~2 seconds):**
- Verify `python3` is on PATH
- Run `python3 -c "import bs4; import requests"` to check pip packages
- If missing: offer to run `pip install beautifulsoup4 requests`, stop if user declines

**Config check** — read `~/.claude/search-visibility-config.json`:
- Config exists and valid: print one-line status, proceed to audit
- Config missing: run first-time setup flow

**Status line on subsequent runs:**
```
Preflight OK — python3, bs4, requests. Competitor discovery: manual. (/visibility-setup to change)
```

### First-Time Setup Flow

**Question 1: Competitor Discovery Mode**

> How would you like to discover who AI recommends instead of you?
>
> A) Automatic — Provide an OpenAI API key. I'll query ChatGPT programmatically with customer-like prompts and parse the results.
>
> B) Manual — I'll generate 3 prompts for you to paste into ChatGPT yourself. You paste the responses back and I'll analyze them. Free, no API key needed.

If A: ask for API key, validate with test call, store in config.
If B: store `"mode": "manual"`, print instructions about Temporary Chat mode.

**Manual mode instructions (shown once during setup):**

> When we get to competitor discovery, I'll give you 3 numbered prompts. For each one:
> 1. Open ChatGPT and start a new Temporary Chat (click the dropdown next to the model name, toggle Temporary Chat ON). This prevents ChatGPT's memory from biasing results.
> 2. Each prompt gets its own separate Temporary Chat. Don't run multiple prompts in the same chat — ChatGPT will repeat brands from earlier responses.
> 3. Paste the prompt, copy the full response.
> 4. Paste all 3 responses back here, labeled 1-3.

### Config File

Location: `~/.claude/search-visibility-config.json`

```json
{
  "competitor_discovery": "manual",
  "openai_api_key": null,
  "setup_version": 1
}
```

`setup_version` allows future setup questions to be added without re-running the full flow.

### Competitor Discovery During Audit

Both modes share prompt generation logic. Claude reads extraction data (title, description, H1) and generates customer-like prompts directly from the extraction JSON.

**Automatic mode (API key):**
- Pipe extraction JSON to `discover_competitors.py --brand "X" --api-key KEY`
- 5 prompts (API calls have no friction cost)
- Parse JSON result, present competitors

**Manual mode:**
- Claude generates 3 prompts from extraction data
- Presents prompts with short reminder: "Open 3 separate Temporary Chats in ChatGPT"
- User pastes responses back labeled 1-3
- Claude parses responses directly — identifies brands, counts frequency, checks whether user's brand appeared
- No Python script involved

Manual mode uses 3 prompts (not 5) to reduce friction. Automatic mode keeps 5.

### `/visibility-setup` Command

Thin command that forces the setup flow to re-run. Reads existing config, shows current settings, asks if user wants to change.

## Files to Change

| File | Action | What changes |
|------|--------|-------------|
| `skills/audit/SKILL.md` | Modify | Add preflight section before Step 1, rewrite Step 1 competitor discovery with two paths |
| `commands/visibility.md` | Modify | Add preflight reference at top of Phase 1 |
| `commands/visibility-setup.md` | Create | Thin command to re-run setup |
| `discover_competitors.py` | No change | Still used for automatic mode |

No new Python scripts. Manual mode is entirely Claude-native.
