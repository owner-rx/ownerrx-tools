---
name: strategy
description: Distribution strategy evaluation for AI search visibility. Evaluates Reddit, Lovable, Replit, and Documentation models against your business type and audit results. Use after the audit skill has completed.
version: 1.0.0
---

# Strategy & Plan

Evaluate distribution strategies to increase AI search discoverability beyond page-level optimization. Uses audit results to determine which models fit your business.

## Prerequisites

This skill expects the following data from the audit phase:
- `page_audit`: Full extraction JSON from `analyze_page.py`
- `site_audit`: Canonical page check from `site_audit.py`
- `competitor_data`: Competitor discovery results
- `competitor_site_audits`: Site audit results for each competitor domain

## Workflow

### Step 1: Classify Business Type

Run the strategy evaluator:

```bash
echo '{combined_audit_json}' | python3 ${CLAUDE_PLUGIN_ROOT}/scripts/strategy_evaluator.py
```

Where `combined_audit_json` is:
```json
{
  "page_audit": { ... },
  "site_audit": { ... },
  "competitor_data": { ... },
  "competitor_site_audits": { ... }
}
```

Present the business classification to the user:
- "Based on your site, I've classified your business as: **[type]**"
- Show the signals that led to this classification

### Step 2: Present Strategy Brief

For each model returned as `applicable: true`, present a **2-3 paragraph brief**:

**[Model Name] — Priority: [HIGH/MEDIUM/LOW]**

> [rationale from evaluator]
>
> [competitor_gap if non-empty]
>
> **30-day outline:**
> - Week 1: [specific first action]
> - Week 2-3: [build momentum action]
> - Week 4: [measure and iterate action]

For models returned as `applicable: false`, include a single line:
> **[Model Name]** — Not applicable: [rationale]

### Step 3: Unified Action Plan

Merge strategy recommendations with audit fixes into one prioritized list:

**High Impact (this week):**
- Audit fixes (show-stoppers, schema, robots.txt)
- Strategy quick wins (e.g., "Create /how-it-works page")

**Medium Impact (this month):**
- Remaining audit fixes
- First Reddit thread or first metric post
- Build missing canonical pages

**Low Impact (when you get to it):**
- Minor audit items
- Long-term strategy plays

Read `${CLAUDE_PLUGIN_ROOT}/references/strategy-models.md` for model definitions and playbook details.
