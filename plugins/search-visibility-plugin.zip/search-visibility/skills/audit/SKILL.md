---
name: audit
description: Audit any webpage for search engine and AI search visibility. Scores across 6 research-backed categories (Authority, Content Structure, Entity Clarity, Technical Foundation, AI Crawlability, Freshness), compares against competitors, checks site-level canonical pages, detects topic clusters, classifies query intent, and generates ready-to-use fixes. Based on Princeton GEO (2024), GEO-16 (2025), and E-E-A-T research.
version: 1.0.0
---

# Audit & Improve

Audit any webpage for traditional search engine and AI search visibility. Score against 6 research-backed categories. Compare against competitors. Check site-level coverage. Generate ready-to-use fixes. Deliver a prioritized action plan.

Based on Princeton GEO (KDD 2024), GEO-16 (2025), and E-E-A-T citation research (Qwairy 2025).

## Workflow

### Preflight: Environment & Config

Run this before anything else, every time.

**1. Check environment**

Run these two commands:

```bash
which python3
```

```bash
python3 -c "import bs4; import requests" 2>&1
```

- If `python3` is not found: stop and tell the user to install Python 3.
- If the import check fails: tell the user which package is missing and offer to run `pip install beautifulsoup4 requests`. If they decline, stop.

**2. Check config**

Read `~/.claude/search-visibility-config.json`.

- **Config exists and valid:** Print one status line and proceed:
  > `Preflight OK — python3, bs4, requests. Competitor discovery: [manual/automatic]. (/visibility-setup to change)`

- **Config missing or invalid:** Run the first-time setup flow below.

**3. First-time setup flow**

Ask the user:

> How would you like to discover who AI recommends instead of you?
>
> **A) Automatic** — Provide an OpenAI API key. I'll query ChatGPT programmatically with customer-like prompts and parse the results automatically.
>
> **B) Manual** — I'll generate 3 prompts for you to paste into ChatGPT yourself. You paste the responses back and I'll analyze them. Free, no API key needed.

**If A (automatic):**
1. Check that the `openai` pip package is installed by running `python3 -c "import openai" 2>&1`. If not installed, offer to run `pip install openai`. If they decline, suggest switching to manual mode.
2. Ask for their OpenAI API key.
3. Validate it by running:
   ```bash
   python3 -c "from openai import OpenAI; c = OpenAI(api_key='KEY'); c.models.list()" 2>&1
   ```
   If validation fails, report the error and ask them to try again or switch to manual mode.
4. Write config:
   ```json
   {"competitor_discovery": "automatic", "openai_api_key": "sk-...", "setup_version": 1}
   ```

**If B (manual):**
1. Print these instructions:
   > When we get to competitor discovery, I'll give you 3 numbered prompts. For each one:
   > 1. Open ChatGPT and start a **new Temporary Chat** (click the dropdown next to the model name, toggle "Temporary Chat" ON). This prevents ChatGPT's memory from biasing results toward brands you've discussed before.
   > 2. Each prompt gets its **own separate Temporary Chat**. Don't run multiple prompts in the same chat — ChatGPT will repeat brands from earlier responses.
   > 3. Paste the prompt, copy the full response.
   > 4. Paste all 3 responses back here, labeled 1-3.
2. Write config:
   ```json
   {"competitor_discovery": "manual", "openai_api_key": null, "setup_version": 1}
   ```

Write the config file to `~/.claude/search-visibility-config.json`.

Proceed to Step 1.

### Step 1: Collect Input

Ask the user for:

1. **Target URL** (primary) — or ask them to paste their page content as fallback.
2. **Brand name** — "What is your brand/company name?" (needed for competitor discovery in both modes).
3. **Competitor URLs** — "Provide 2-3 competitor URLs, OR I can discover your top AI competitors automatically."

If the user wants auto-discovery, read the competitor discovery mode from `~/.claude/search-visibility-config.json`.

**Automatic mode** (`"competitor_discovery": "automatic"`):

1. Use WebFetch to get the user's page HTML.
2. Save to a temp file and run extraction:
   ```bash
   python3 ${CLAUDE_PLUGIN_ROOT}/scripts/analyze_page.py --file /tmp/target_page.html --url {url}
   ```
3. Read the API key from the config file. Pipe extraction JSON to discover competitors:
   ```bash
   echo '{extraction_json}' | python3 ${CLAUDE_PLUGIN_ROOT}/scripts/discover_competitors.py --brand "{brand_name}" --api-key {api_key}
   ```
4. Present discovered competitors to the user for confirmation.
5. Report whether the user's brand was mentioned by AI at all.

**Manual mode** (`"competitor_discovery": "manual"`):

1. Use WebFetch to get the user's page HTML.
2. Save to a temp file and run extraction:
   ```bash
   python3 ${CLAUDE_PLUGIN_ROOT}/scripts/analyze_page.py --file /tmp/target_page.html --url {url}
   ```
3. Read the extraction JSON. From the `meta.title`, `meta.description`, and `headings.h1[0]` fields, generate 3 customer-like prompts. These should be natural questions a potential customer would ask when looking for solutions in this space. Examples of prompt patterns:
   - "What are the best alternatives for [niche inferred from title/description]?"
   - "Can you recommend the top companies or tools for [description]?"
   - "Who are the market leaders in [category]?"
4. Present the 3 prompts numbered, with this reminder:
   > Open **3 separate Temporary Chats** in ChatGPT (one per prompt). Toggle "Temporary Chat" ON each time to prevent memory bias. Paste each prompt, copy the response, then paste all 3 responses back here labeled 1-3.
5. Wait for the user to paste their responses.
6. Parse the responses:
   - Identify brand names mentioned across all 3 responses.
   - Count how many responses each brand appears in (max 3).
   - Check whether the user's brand name was mentioned in any response.
   - Rank competitors by mention frequency. Take the top 3.
7. Present results:
   - "**Competitors discovered:** [Brand1] (mentioned in 3/3 responses), [Brand2] (2/3), [Brand3] (2/3)"
   - "**Your brand ([name]):** [Mentioned in 1/3 responses / Not mentioned in any response]"
   - "**Prompts used:** [list the 3 prompts]"
8. Ask the user to confirm the competitor list or adjust it.

### Step 2: Detect MCP Capabilities

Check your available tools for MCP integrations that enhance the audit:

**Lighthouse MCP** — Look for tools named like `run_audit`, `get_core_web_vitals`, `lighthouse_audit`, or similar performance audit tools. If found, these replace heuristic CWV estimates with measured LCP, INP, and CLS values.

**Google Search Console MCP** — Look for tools named like `search_analytics`, `get_search_performance`, `gsc_query`, or similar. If found, pull actual click/impression data and indexing status.

Report to the user what was detected:

- "Lighthouse MCP detected — I will use measured Core Web Vitals instead of heuristics."
- "Google Search Console MCP detected — I will pull actual search performance data."
- "No optional MCP servers detected — I will use heuristic analysis for CWV and skip search performance data. Results will note where measured data would improve accuracy."

### Step 3: Extract Data

For each URL (target + competitors), collect data from all available sources.

**3a. Fetch page assets**

Use WebFetch to retrieve:

1. The page HTML — save to `/tmp/{domain}_page.html`
2. `{scheme}://{domain}/robots.txt` — save to `/tmp/{domain}_robots.txt`
3. `{scheme}://{domain}/llms.txt` — this may 404, that is fine. If it exists, save to `/tmp/{domain}_llms.txt`

Note any relevant HTTP response headers (especially `X-Robots-Tag`). If headers are available, save them to `/tmp/{domain}_headers.json`.

**3b. Run page analyzer**

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/analyze_page.py \
  --file /tmp/{domain}_page.html \
  --url {url} \
  --robots /tmp/{domain}_robots.txt \
  [--llms-txt /tmp/{domain}_llms.txt] \
  [--headers-json /tmp/{domain}_headers.json]
```

Omit `--llms-txt` if the llms.txt fetch returned 404. Omit `--headers-json` if no relevant headers were captured.

This outputs a JSON object with keys: `url`, `meta`, `headings`, `content`, `authority`, `technical`, `anti_patterns`, `eeat`, `llms_txt`, `x_robots_tag`, `internal_links`, `query_intent`.

**3c. Run site-level audit**

For the target domain (and each competitor domain):

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/site_audit.py {base_url}
```

This checks 10 canonical pages (/how-it-works, /use-cases, /pricing, /faq, /about, /glossary, /changelog, /blog, /docs, /documentation) and returns coverage score, found pages, and missing pages.

**3d. Run technical checker**

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/scripts/technical_checker.py {url}
```

This outputs a JSON object with keys: `ssl`, `redirects`, `security_headers`, `page_speed`, `sitemap`, `cwv_heuristic`.

**3e. Lighthouse MCP (if available)**

If Lighthouse MCP tools were detected in Step 2, run the audit tool for each URL. Extract:

- LCP (Largest Contentful Paint) in seconds
- INP (Interaction to Next Paint) in milliseconds
- CLS (Cumulative Layout Shift) score
- Performance score (0-100)

When Lighthouse data is available, use it instead of the `cwv_heuristic` values from `technical_checker.py`. Note `"source": "lighthouse"` instead of `"source": "heuristic"` in the results.

**3f. Google Search Console MCP (if available)**

If GSC MCP tools were detected in Step 2, pull for the target URL:

- Total clicks and impressions (last 28 days)
- Top queries driving traffic
- Indexing status

**3g. Merge results**

Combine `analyze_page.py` output, `site_audit.py` output, `technical_checker.py` output, and any MCP data into a single extraction JSON per page.

### Step 4: Score

Read `${CLAUDE_PLUGIN_ROOT}/references/scoring-rubric.md` for the detailed rubric with score ranges, sub-checks, and deductions.

For each page, assign a 0-100 score per category:

| Category | Weight | Primary Data Source |
|---|---|---|
| Authority & Citability | 30% | `authority` + `eeat` sections |
| Content Structure | 20% | `headings` + `content` sections |
| Entity Clarity | 15% | `authority.named_entities` + `authority.vague_claims` + schema |
| Technical Foundation | 20% | `technical` section + `technical_checker.py` output |
| AI Crawlability | 10% | `technical` bot analysis + `llms_txt` + `x_robots_tag` |
| Freshness | 5% | `meta` dates + `eeat.article_dates` + `technical_checker` headers |

Calculate the composite score:

```
composite = (authority * 0.30) + (structure * 0.20) + (technical * 0.20) + (entity * 0.15) + (ai_crawlability * 0.10) + (freshness * 0.05)
```

**Score modifiers from new signals:**
- If `internal_links.orphan_risk` is true: -10 from Content Structure score
- If `query_intent.intent_type` is "branded" with no decision-level framing: -10 from Authority & Citability score

**Critical checks:**

- If `technical.is_ssr` is false: flag as a show-stopper. The page is invisible to AI crawlers. Set Technical Foundation to 0.
- If `technical.is_spa_port` is true: flag as a show-stopper. The page uses Next.js but still fetches content client-side — a "ported SPA" that gains no visibility benefit. Set Technical Foundation to max 20. The fix is not to add content tweaks but to move content rendering into Server Components.

### Step 5: Report Card

Present a side-by-side comparison table:

```
                        Target   Comp1    Comp2    Comp3
Authority & Citability    32      71       65       58
Content Structure         55      68       72       61
Entity Clarity            28      64       59       53
Technical Foundation      70      85       80       75
AI Crawlability           45      80       70       65
Freshness                 60      80       70       65
--------------------------------------------------------------
COMPOSITE                 46      74       70       64
```

Below the table, provide a sub-score breakdown for each category on the target page. For each category where the target scores lower than the top competitor:

- State the gap with specific numbers from the extraction data (e.g., "You have 2 statistics, Competitor A has 14").
- Reference the research basis (e.g., "Princeton GEO found statistics addition improves visibility by 25.9%").
- Skip categories where the target is competitive (within 10 points of the leader).

**Query Intent Flag:**

If `query_intent.intent_type` is "branded":
> "Your page title targets a branded query. LLMs are asked decision-level questions ('best X for Y', 'X vs Y'). Consider reframing to target decision queries."

If `query_intent.is_decision_query` is true:
> "Your page targets a decision-level query — this is optimal for AI citation."

**Topic Cluster Flag:**

If `internal_links.orphan_risk` is true:
> "This page has only [N] internal links. Pages with 3+ contextual internal links are cited more consistently. Build supporting pages around this topic."

**Site Coverage Section:**

Present the site-level audit results:

```
Site Coverage: 40% (4/10 canonical pages)

Found: /pricing, /about, /blog, /faq
Missing (high priority): /how-it-works, /use-cases
Missing (medium priority): /glossary, /changelog, /docs
```

**Flag show-stoppers** prominently:

- `is_ssr` is false — "SHOW-STOPPER: Page is not server-side rendered. AI crawlers see an empty page."
- `is_spa_port` is true — "SHOW-STOPPER: This page uses Next.js but still fetches content client-side (detected [N] client-fetch signals with only [N] words server-rendered). You ported the SPA without converting it. You must: (1) Move content into Server Components, (2) Render content on the server, (3) Remove 'use client' except where truly needed for interactivity. Until this is fixed, AI crawlers see a shell, not your content."
- Citation bots blocked — "SHOW-STOPPER: Citation bots (ChatGPT-User, PerplexityBot) are blocked in robots.txt. Your content cannot appear in AI search results."

Note data source quality: "CWV scores based on heuristic analysis" or "CWV scores based on Lighthouse MCP measurement" as applicable.

### Step 6: Generate Fixes

**6a. Run fix generator**

Pipe the target page's extraction JSON to the fix generator:

```bash
echo '{extraction_json}' | python3 ${CLAUDE_PLUGIN_ROOT}/scripts/fix_generator.py
```

This outputs a JSON object with keys: `schema_fixes`, `llms_txt`, `robots_fixes`, `meta_fixes`, `weak_sections`.

**6b. Present schema fixes**

For each entry in `schema_fixes`, present the ready-to-paste JSON-LD block:

```
**Missing: FAQPage Schema**
Reason: FAQ content detected on page but FAQPage schema is missing. 82% of AI citations include structured data.

Add this to your page's <head>:
<script type="application/ld+json">
{ ... generated schema ... }
</script>
```

**6c. Present llms.txt**

If `llms_txt` content was generated, present it:

```
**Generated llms.txt**
Save this file at your domain root (e.g., https://example.com/llms.txt):

# Site Title
> Site description

## Pages
- [Page Title](url): description
```

**6d. Present robots.txt fixes**

If `robots_fixes` content was generated, present the corrected rules with the training-vs-citation bot explanation.

**6e. Present meta tag fixes**

If `meta_fixes` contains suggestions, present them. For Next.js projects, generate a TypeScript metadata export.

**6f. Rewrite weak sections**

Read `${CLAUDE_PLUGIN_ROOT}/references/princeton-techniques.md` for rewriting methods.

Using the `weak_sections` output, identify the 3-5 weakest sections. For each, apply the top 3 Princeton techniques (Statistics Addition, Citation Addition, Quotation Addition) and present original vs. fixed side-by-side.

Mark any placeholder data or quotes clearly with `[REPLACE: ...]` so the owner knows what to fill in with real information. Preserve the owner's voice and tone.

### Step 7: Action Plan

Produce a prioritized checklist grouped by impact level. Write instructions for non-technical people. Use plain language. If something requires a developer, say "Ask your developer to..."

Include missing canonical pages from the site audit in the appropriate priority tier.

**High Impact (this week):**
Actions based on the biggest scoring gaps and show-stoppers.

**Medium Impact (this month):**
Structural and technical changes that take more effort, including building missing canonical pages.

**Low Impact (when you get to it):**
Minor optimizations and maintenance items.

## Dependencies

Scripts require:

```bash
pip install beautifulsoup4 requests
```

Optional (for automatic competitor discovery mode):

```bash
pip install openai
```

The preflight check at the start of the workflow validates these automatically.

## Config

Plugin config is stored at `~/.claude/search-visibility-config.json`. Run `/visibility-setup` to reconfigure.
