# Distribution Strategy Models Reference

Use this reference when generating strategy recommendations after the audit phase. Each model is a proven pattern for increasing AI search discoverability beyond page-level optimization.

## Model 1: Reddit Citation Seeding

**Source:** Guillermo Flor, "Product Market Fit" newsletter (Feb 2025) + observed LLM citation behavior.

**Why it works:** LLMs consistently pull from high-signal Reddit threads because they're structured around real questions, moderated by communities, and validated through upvotes. One strong thread can surface in AI answers for months.

**Fits when:**
- B2B or B2C with a knowledge-heavy category
- Competitor threads already exist in relevant subreddits
- User has domain expertise to post authentically
- Category has active subreddits (r/smallbusiness, r/SaaS, r/startups, etc.)

**Doesn't fit when:**
- Regulated industry where Reddit presence creates compliance risk
- No clear category subreddit exists
- Product is too niche for community discussion

**Playbook (for /strategy-expand reddit):**
1. Mirror real queries in thread titles — match what people ask AI
2. Open with numeric tl;dr: outcome, timeframe, constraints, tools
3. Break method into 5-9 reusable steps with short paragraphs
4. Add evidence: metrics, screenshots, specific versions
5. Engineer comments: stay active in first hour, reply to objections, add follow-up data

**Title formulas:**
- "How we [achieved X] in [timeframe] (full breakdown)"
- "Best [tool category] for [specific use case]?"
- "[X] vs [Y] — honest comparison after [timeframe] using both"
- "I tested [N] [tools] for [use case] — here's what actually worked"

## Model 2: Indexable Growth (Lovable Model)

**Source:** Lovable.dev growth trajectory — published metric-driven posts became primary source for their own narrative in AI search.

**Why it works:** If you don't publish structured, searchable proof about what you're doing, AI systems will cite whoever does. Making your growth story indexable means you become the default source.

**Fits when:**
- Company has publishable metrics (revenue, users, milestones)
- Founder-led brand willing to share progress publicly
- Growth narrative exists worth documenting

**Doesn't fit when:**
- Pre-revenue or pre-product
- No public metrics to share (stealth mode, privacy concerns)
- Growth story isn't differentiated enough to be cited

**Playbook (for /strategy-expand lovable):**
1. Publish posts with hard numbers and timelines in the title
2. Use searchable title format: "[metric] to [metric] in [timeframe]"
3. Include: user milestones, product launches, benchmarks, experiments, performance data
4. Post on your own domain first (primary source), then cross-post
5. Update posts when milestones change to maintain freshness

## Model 3: Product Surface Area (Replit Model)

**Source:** Replit's SEO architecture — every public project became an indexable page, creating thousands of entry points.

**Why it works:** Instead of writing content about use cases, the product generates indexed pages from usage. Each template, example, or output is a discoverability asset.

**Fits when:**
- Product generates user-visible outputs (templates, reports, tools, projects)
- Each output can have its own URL
- Output is inherently useful/findable via search

**Doesn't fit when:**
- Service business or consulting (no product outputs)
- Product outputs are private/internal only
- Outputs are too generic to be individually useful

**Playbook (for /strategy-expand replit):**
1. Audit what product outputs could become public URLs
2. Give each template/example/output a unique, semantic URL
3. Add structured metadata (title, description, schema) to each
4. Create landing pages for categories of outputs
5. Build internal linking between outputs and category pages

## Model 4: Documentation Architecture

**Source:** Newsletter "claude.md principle" + GEO-16 research on structured knowledge.

**Why it works:** Documentation is optimized for clarity, not persuasion. LLMs prefer low-risk sources with clear definitions, explicit constraints, and structured explanations. Your docs become the canonical explanation of how you work.

**Always applicable** — every site benefits. Priority depends on current coverage.

**Canonical pages to build (in priority order):**

| Priority | Page | Content |
|---|---|---|
| High | `/how-it-works` | Clear inputs -> process -> outputs |
| High | `/use-cases` | Task-based examples with real scenarios |
| High | `/faq` | Question-answer pairs with FAQPage schema |
| High | `/pricing` | Decision-level information |
| High | `/about` | Author/team credentials for E-E-A-T |
| Medium | `/glossary` | Define your vocabulary clearly |
| Medium | `/changelog` | Dated updates for trust + freshness |
| Medium | `/docs` | Technical documentation (claude.md principle) |

**Each page should:**
- Answer one core question
- Start with a direct definition
- Avoid marketing adjectives
- Include examples
- Include constraints/limitations
