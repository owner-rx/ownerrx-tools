---
name: visibility-setup
description: Configure or reconfigure the search-visibility plugin. Checks environment and sets competitor discovery mode.
user_invocable: true
---

# /visibility-setup

Reconfigure the search-visibility plugin.

## Instructions

Run the Preflight section from the `audit` skill in this plugin, but **force re-setup** even if a config file already exists at `~/.claude/search-visibility-config.json`.

1. Run the environment check (python3, pip packages).
2. If a config file exists, read it and show the current settings:
   > "Current config: Competitor discovery mode is **[manual/automatic]**. Want to change? (yes/no)"
3. If yes (or no config exists), run the first-time setup flow from the audit skill's Preflight section.
4. Save the updated config.
5. Confirm: "Setup complete. Run `/visibility [url]` to start an audit."
