---
name: visibility
description: Run a full AI search visibility audit and strategy evaluation for any URL. Scores against 6 categories, compares to competitors, generates fixes, and recommends distribution strategies.
user_invocable: true
argument: url (required) - The URL to audit
---

# /visibility

Run a complete AI search visibility audit and strategy plan.

## Instructions

You are running the full search-visibility pipeline. Follow these two phases in order.

### Phase 1: Audit

Use the `audit` skill from this plugin. Run the full audit workflow:

0. **Run Preflight** — environment check + config check (see audit skill Preflight section).
1. Collect the target URL from the argument. Ask for brand name and competitor URLs (or offer auto-discovery).
2. Detect MCP capabilities (Lighthouse, Google Search Console).
3. Extract data for target and competitors (page-level + site-level).
4. Score all 6 categories.
5. Present the report card with competitor comparison.
6. Generate fixes (schema, llms.txt, robots.txt, meta, weak sections).

Save the audit results — they feed into Phase 2.

### Phase 2: Strategy

Use the `strategy` skill from this plugin. Pass the audit results:

1. Classify business type.
2. Evaluate all 4 models (Reddit, Lovable, Replit, Documentation).
3. Check competitor strategic positioning.
4. Present the prioritized strategy brief.
5. Produce the unified action plan (audit fixes + strategy plays combined).

### Follow-up

After presenting results, tell the user:

> "To expand any strategy into a full playbook, run `/strategy-expand [model]` where model is: reddit, lovable, replit, or documentation."
