---
name: strategy-expand
description: Expand a strategy model into a full playbook. Use after /visibility has identified applicable strategies.
user_invocable: true
argument: model (required) - One of: reddit, lovable, replit, documentation
---

# /strategy-expand

Generate a detailed playbook for one distribution strategy model.

## Instructions

Read `${CLAUDE_PLUGIN_ROOT}/references/strategy-models.md` for the full model definition and playbook template.

Based on the model argument:

### reddit
Generate:
- 5 Reddit thread titles tailored to the user's business and category
- Target subreddit recommendations (research which subreddits discuss their category)
- Posting schedule (1 thread/week for 4 weeks)
- Comment engineering plan (what to reply to, when to add follow-up data)
- Numeric tl;dr template pre-filled with their business context

### lovable
Generate:
- What metrics the business should publish (based on audit data)
- 5 title formulas filled with their specific numbers/milestones
- Posting cadence recommendation
- Platform targets (own blog, LinkedIn, Twitter)
- Template for a metric-driven post

### replit
Generate:
- Inventory of product outputs that could become indexable pages
- URL structure recommendation for each output type
- Metadata template (title, description, schema) for output pages
- Internal linking strategy between outputs and category pages
- Example of one fully fleshed-out template page

### documentation
Generate:
- Full page inventory based on their missing canonical pages (from site audit)
- For each missing page, a 5-10 line content outline
- Schema markup recommendation per page
- Internal linking map between documentation pages
- Priority order for building pages

Always tailor recommendations to the specific business, using data from the most recent /visibility audit in this conversation.
